
function loadCSV() {
  fetch('distraction_detector_with_names.csv')
    .then(response => response.text())
    .then(csv => {
      const parsed = Papa.parse(csv, { header: true });
      const data = parsed.data;

      let html = '<table><thead><tr>';
      Object.keys(data[0]).forEach(col => {
        html += `<th>${col}</th>`;
      });
      html += '</tr></thead><tbody>';

      data.forEach(row => {
        html += '<tr>';
        Object.values(row).forEach(cell => {
          html += `<td>${cell}</td>`;
        });
        html += '</tr>';
      });

      html += '</tbody></table>';
      document.getElementById('table-container').innerHTML = html;
    });
}

function downloadPDF() {
  const element = document.getElementById('table-container');
  html2pdf().from(element).save('student_dashboard.pdf');
}

document.getElementById("searchInput").addEventListener("input", function () {
  const value = this.value.toLowerCase();
  const rows = document.querySelectorAll("tbody tr");
  rows.forEach(row => {
    row.style.display = Array.from(row.cells).some(td =>
      td.innerText.toLowerCase().includes(value)
    ) ? "" : "none";
  });
});

loadCSV();
